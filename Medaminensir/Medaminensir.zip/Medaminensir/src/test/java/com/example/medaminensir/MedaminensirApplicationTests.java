package com.example.medaminensir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedaminensirApplicationTests {

	@Test
	void contextLoads() {
	}

}
