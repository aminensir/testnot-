package com.example.medaminensir.repository;
import com.example.medaminensir.entity.Cours;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoursRepository extends JpaRepository<Cours,Long>{
}
