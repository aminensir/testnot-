package com.example.medaminensir.repository;

import com.example.medaminensir.entity.Moniteur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MoniteurRepository extends JpaRepository<Moniteur,Long> {
}
