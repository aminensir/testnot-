package com.example.medaminensir.entity;

public enum Support {
    SKI,
    SNOWBOARD
}
