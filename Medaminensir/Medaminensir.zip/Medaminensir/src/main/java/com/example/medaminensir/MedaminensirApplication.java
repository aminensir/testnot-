package com.example.medaminensir;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedaminensirApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedaminensirApplication.class, args);
	}

}
