package com.example.medaminensir.entity;

public enum TypeCours {
    COLLECTIF_ENFANT,
    COLLECTIF_ADULTE,
    PARTICULIER
}
