package com.example.medaminensir.repository;

import com.example.medaminensir.entity.Abonnement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AbonnementRepository extends JpaRepository<Abonnement,Long> {
}
