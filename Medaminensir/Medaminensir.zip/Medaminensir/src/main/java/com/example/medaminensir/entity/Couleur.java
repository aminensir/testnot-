package com.example.medaminensir.entity;

public enum Couleur {
    VERT,
    BLEU,
    ROUGE,
    NOIR
}
