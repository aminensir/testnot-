package com.example.medaminensir.entity;

public enum TypeAbonnement {
    ANNUEL,
    SEMESTRIEL,
    MENSUEL

}
